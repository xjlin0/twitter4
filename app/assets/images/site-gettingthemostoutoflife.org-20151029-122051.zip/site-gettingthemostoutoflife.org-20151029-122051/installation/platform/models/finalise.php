<?php
/**
 * @package angi4j
 * @copyright Copyright (C) 2009-2014 Nicholas K. Dionysopoulos. All rights reserved.
 * @author Nicholas K. Dionysopoulos - http://www.dionysopoulos.me
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL v3 or later
 */

defined('_AKEEBA') or die();

class AngieModelFinalise extends AModel
{
	/**
	 * Post-restoration cleanup. Renames files and removes the installation directory.
	 *
	 * @return bool
	 */
	public function cleanup()
	{
		$result = true;

		// Remove installation directory
		$result = $this->recursive_remove_directory(APATH_INSTALLATION);

		// Rename the backup .htaccess and php.ini files
		$files_map = array(
			APATH_ROOT . '/htaccess.bak'	=> APATH_ROOT . '/.htaccess',
			APATH_ROOT . '/web.config.bak'	=> APATH_ROOT . '/web.config',
			APATH_ROOT . '/php.ini.bak'		=> APATH_ROOT . '/php.ini',
		);

		foreach ($files_map as $from => $to)
		{
			if (!file_exists($from))
			{
				continue;
			}

			if (file_exists($to))
			{
				if (!@unlink($to))
				{
					continue;
				}
			}

			@rename($from, $to);
		}

		return $result;
	}

	/**
	 * Recursively remove a directory from the server
	 *
	 * @param   string   $directory  The path to the directory to remove
	 * @param   boolean  $empty      Set to true to only empty the directory but not completely delete it
	 *
	 * @return  boolean  True on success, false on failure
	 */
	function recursive_remove_directory($directory, $empty=false)
	{
		// If the path has a slash at the end we remove it here
		if (substr($directory, -1) == '/')
		{
			$directory = substr($directory, 0, -1);
		}

		// If the path is not valid or is not a directory ...
		if (!file_exists($directory) || !is_dir($directory))
		{
			// ... we return false and exit the function
			return false;
		}
		// If the path is not readable...
		elseif (!is_readable($directory))
		{
			// ... we return false and exit the function
			return false;
		}
		// ... else if the path is readable
		else
		{
			// We open the directory
			$handle = opendir($directory);

			// and scan through the items inside
			while (false !== ($item = readdir($handle)))
			{
				// if the filepointer is not the current directory
				// or the parent directory
				if ($item != '.' && $item != '..')
				{
					// We build the new path to delete
					$path = $directory.'/'.$item;

					// If the new path is a directory...
					if(is_dir($path))
					{
						// ...we call this method with the new path
						$this->recursive_remove_directory($path);
					}
					// If the new path is a file...
					else
					{
						// ...we remove the file
						@unlink($path);
					}
				}
			}

			// Close the directory
			closedir($handle);

			// If the option to empty is not set to true
			if ($empty == false)
			{
				// Try to delete the now empty directory
				if (!@rmdir($directory))
				{
					// return false if not possible
					return false;
				}
			}
			// return success
			return true;
		}
	}

	public function updatehtaccess()
	{
		// Make sure we have a file
		$fileName = APATH_ROOT . '/.htaccess';

		if (!@file_exists($fileName))
		{
			$fileName = APATH_ROOT . '/htaccess.bak';
		}

		if (!@file_exists($fileName))
		{
			return true;
		}

		// Get the site's URL
		/** @var AngieModelConfiguration $config */
		$config  = AModel::getAnInstance('Configuration', 'AngieModel');
		$new_url = $config->get('siteurl');
		$homeurl = $config->get('homeurl');
		$newURI = new AUri($new_url);
		$path = $newURI->getPath();

		// Load the .htaccess in memory
		$contents = @file_get_contents($fileName);

		if ($contents === false)
		{
			return false;
		}

		// Explode its lines
		$lines = explode("\n", $contents);
		$contents = '';
		$inSection = null;

		foreach ($lines as $line)
		{
			// Fix naughty Windows users' doing
			$line = rtrim($line, "\r");

			// If we are not inside the WordPress section look for the BEGIN signature
			if (is_null($inSection))
			{
				if (strpos($line, '# BEGIN WordPress') === 0)
				{
					$inSection = true;
				}
			}
			// If we are inside the WordPress section do the necessary manipulation
			elseif ($inSection)
			{
				if (strpos($line, '# END WordPress') === 0)
				{
					$inSection = false;
				}
				elseif (strpos($line, 'RewriteBase ') === 0)
				{
					$line = "RewriteBase $path";

					// If the site is hosted on the domain's root
					if (empty($path))
					{
						$line = "RewriteBase /";
					}
				}
				elseif (strpos($line, 'RewriteRule .') === 0)
				{
					$line = 'RewriteRule . ' . $path . '/index.php [L]';
				}
			}

			// Add the line
			$contents .= "$line\n";
		}

		// Write the new .htaccess
		$fileName = APATH_ROOT . '/.htaccess';
		file_put_contents($fileName, $contents);

		// If the homeurl and siteurl don't match, copy the .htaccess file and index.php in the correct directory
		if ($new_url != $homeurl)
		{
			$homeUri = new AUri($homeurl);
			$homePath = $homeUri->getPath();

			if (strpos($path, $homePath) !== 0)
			{
				// I have no clue where to put the files so I'll do nothing at all :s
				return true;
			}

			// $homePath is WITHOUT /wordpress_dir (/foobar); $path is the one WITH /wordpress_dir (/foobar/wordpress_dir)
			$homePath = ltrim($homePath, '/\\');
			$path = ltrim($path, '/\\');
			$homeParts = explode('/', $homePath);
			$siteParts = explode('/', $path);

			$numHomeParts = count($homeParts);
			$siteParts = array_slice($siteParts, $numHomeParts);

			// Relative path from HOME to SITE (WP) root
			$relPath = implode('/', $siteParts);

			// How many directories above the root (where we are restoring) is our site's root
			$levelsUp = count($siteParts);

			// Determine the path where the index.php and .htaccess files will be written to
			$targetPath = APATH_ROOT . str_repeat('/..', $levelsUp);
			$targetPath = realpath($targetPath) ? realpath($targetPath) : $targetPath;

			// Copy the files
			if (!@copy(APATH_ROOT . '/.htaccess', $targetPath . '/.htaccess'))
			{
				return false;
			}

			if (!@copy(APATH_ROOT . '/index.php', $targetPath . '/index.php'))
			{
				return false;
			}

			// Edit the index.php file
			$fileName = $targetPath . '/index.php';
			$fileContents = @file($fileName);

			if (empty($fileContents))
			{
				return false;
			}

			foreach ($fileContents as $index => $line)
			{
				$line = trim($line);

				if (strstr($line, 'wp-blog-header.php') && (strpos($line, 'require') === 0))
				{
					$line = "require( dirname( __FILE__ ) . '/$relPath/wp-blog-header.php' );";
				}

				$fileContents[$index] = $line;
			}

			$fileContents = implode("\n", $fileContents);
			@file_put_contents($fileName, $fileContents);
		}

		return true;
	}
}